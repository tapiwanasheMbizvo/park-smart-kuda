<?php
namespace Paynow\Core;

/**
 * Class Logger
 * @package Paynow\Core
 *
 * @todo Implement logging functionality
 */
class Logger
{

}