<?php
namespace Paynow\Payments;


class NotImplementedException extends \Exception { }